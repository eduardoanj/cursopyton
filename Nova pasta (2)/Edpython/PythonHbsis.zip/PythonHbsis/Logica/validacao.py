
def valida(cond1):
    return cond1
d1 = {}
d2 = {'nome':'Maykon', 'numero_c':'15000', 'saldo':-12000 }



if(d2):
    print('Verdadeiro')
else:
    print('False')