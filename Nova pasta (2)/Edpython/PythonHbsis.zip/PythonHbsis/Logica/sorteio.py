import random
#random sorteia numeros reais, randint sorteia numeros inteiros, só colocar de qual até qual numero deve ser sorteado dentro dos parenteses.
lista = ['guto', 'lucas','jaspion','jiraia','naruto']
num = random.randint(1, 6)

print(lista[num])