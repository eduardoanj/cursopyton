
class carro:
    def __init__(self):
        carro = ('volante':'esportivo', 'rodas':4, 'motor': '1.4','motor':'1.4', 'portas':2, 'cadeiras':3)