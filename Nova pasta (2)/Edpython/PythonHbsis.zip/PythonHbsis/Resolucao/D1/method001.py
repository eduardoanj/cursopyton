def imprimir(caracter):
    print(caracter*40)

def soma(valor1, valor2):
    resultado =valor1 + valor2
    return resultado


imprimir('*')

a = soma(10,20)
b= soma(-10,50)

imprimir('=')

